﻿using HospitalProject.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace HospitalProject.View.PatientView.Model
{
    public class NotificationsViewModel : ViewModelBase
    {
        
        public NotificationsViewModel() {

            
        }
    
    }

}
