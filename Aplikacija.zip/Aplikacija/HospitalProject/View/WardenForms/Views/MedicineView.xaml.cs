﻿using System.Windows.Controls;

namespace HospitalProject.View.WardenForms.Views;

public partial class MedicineView : UserControl
{
    public MedicineView()
    {
        InitializeComponent();
    }
}