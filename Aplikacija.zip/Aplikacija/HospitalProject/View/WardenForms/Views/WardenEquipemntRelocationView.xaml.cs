﻿using System.Windows.Controls;

namespace HospitalProject.View.WardenForms.Views;

public partial class WardenEquipemntRelocationView : UserControl
{
    public WardenEquipemntRelocationView()
    {
        InitializeComponent();
    }

    private void Rooms_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {

    }

    private void Rooms_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
    {

    }
}