// File:    Gender.cs
// Author:  aleksa
// Created: Sunday, March 27, 2022 19:14:44
// Purpose: Definition of Enum Gender

using System;

namespace Model
{
   public enum Gender
   {
      male,
      female
   }
}