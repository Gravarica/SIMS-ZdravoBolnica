﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalProject.Model
{
    public enum Category
    {
        DOCTOR_SURVEY,
        HOSPITAL_SURVEY,
        APPLICATION_SURVEY

    }
}
