using System;

namespace HospitalProject.Model;

public class PatientAllergies
{

}