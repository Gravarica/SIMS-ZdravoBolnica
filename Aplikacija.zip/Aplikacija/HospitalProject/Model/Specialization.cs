// File:    FieldOfWork.cs
// Author:  aleksa
// Created: Sunday, March 27, 2022 18:51:01
// Purpose: Definition of Enum FieldOfWork

using System;

namespace Model
{
    public enum Specialization
    {
        CARDIOLOGY,
        GENERAL,
        SURGERY,
        NEUROLOGY

    }    

}