// File:    BloodType.cs
// Author:  aleksa
// Created: Sunday, March 27, 2022 18:36:56
// Purpose: Definition of Enum BloodType

using System;

namespace Model
{
   public enum BloodType
   {
      a,
      b,
      o,
      ab,
   }
}